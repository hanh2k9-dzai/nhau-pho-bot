# Nhậu Phố Simulator - Telegram Bot

Hướng dẫn đưa bot lên Render:

1. Giải nén tệp `nhau_pho_bot.zip`.
2. Tạo 1 Repository mới trên GitHub và tải toàn bộ các file này lên.
3. Truy cập https://render.com và đăng nhập.
4. Chọn **New +** -> **Background Worker**.
5. Kết nối tới Repository GitHub vừa tạo.
6. Cấu hình cài đặt:
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python main.py`
7. (Tùy chọn) Thêm **Environment Variable**:
   - Key: `BOT_TOKEN`
   - Value: `8910844792:AAE8x-e3UST4my-RhdQvBY-swhv9m8TGBVY`
8. Bấm **Create Background Worker** để khởi chạy.
